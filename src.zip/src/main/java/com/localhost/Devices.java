package com.localhost;

/**
 * Created by Lenovo1 on 24-07-2016.
 */
public class Devices {
    private String deviceType;
    private String model;
    private String name;
    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
