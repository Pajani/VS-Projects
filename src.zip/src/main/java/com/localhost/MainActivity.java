package com.localhost;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView lv;
    HttpGetter hg = new HttpGetter();
    TextView tv ;
    RadioButton rb1,rb2;

    EditText etval;
    Button bConnect;
    String url;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //url = "http://192.168.56.1/simplewebapi/api/GlobalContact/";  //it works fine
        url = "http://192.168.56.1/TestAPI2/api/pincodes/";  //it works fine

        setContentView(R.layout.activity_main);
        tv = (TextView)findViewById(R.id.tv);
        bConnect = (Button)findViewById(R.id.connect) ;
        rb1 = (RadioButton)findViewById(R.id.rb1) ;
        rb2 = (RadioButton)findViewById(R.id.rb2) ;
        etval =(EditText)findViewById(R.id.et) ;
        bConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BackGroundTask bgTask = new BackGroundTask();
                //url = etval.getText().toString();
                url = url + "&search="+etval.getText().toString();
                bgTask.execute(url);
            }
        });

        rb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                url=getResources().getString(R.string.getPinbyNameapi);
            }
        });
        rb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                url=getResources().getString(R.string.getPinbycodeapi);
                etval.se
            }
        });

       //http://182.65.236.123:61369/api/publiccontacts
        //String url = "http://192.168.56.1:61369/api/publiccontacts";
        //String url = "http://192.168.56.1/webapplication2/employee/index";  //it works fine
       // String url = "http://192.168.56.1/simplewebapi/api/values";  //it works fine

        BackGroundTask bgTask = new BackGroundTask();
        bgTask.execute(url);
    }

    public void setContentForListView(String[] names) {
        ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, android.R.id.text1, names);
        lv.setAdapter(listAdapter);
    }

    private class BackGroundTask extends AsyncTask<String, Void, String> {
        ProgressDialog pdLoading = new ProgressDialog(MainActivity.this);
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //this method will be running on UI thread
            pdLoading.setMessage("\tLoading...");
            pdLoading.show();
        }

        @Override
        protected String  doInBackground(String... params) {

           String deviceList = hg.loadDevicesDataFromServer(params[0]);
            return deviceList;
        }

        @Override
        protected void onPostExecute(String deviceList) {
            super.onPostExecute(deviceList);
           /* Devices d;
            String[] dev;
            if (deviceList != null) {
                dev = new String[deviceList.size()];
                for (int j = 0; j < deviceList.size(); j++) {
                    d = (Devices) deviceList.get(j);
                    dev[j] = d.getName();
                }
                setContentForListView(dev);
            } else {
                Toast.makeText(getApplicationContext(), "Device list is NULL", Toast.LENGTH_LONG).show();
                // setContentForListView(fruits);
            }
            //this method will be running on UI thread*/

            pdLoading.dismiss();
            tv.setText(deviceList);

        }

    }
}
