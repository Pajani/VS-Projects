package com.localhost;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

/**
 * Created by Lenovo1 on 24-07-2016.
 */
public class HttpGetter {
    private static String convertStreamToString(InputStream is) {
        /*
         * To convert the InputStream to String we use the BufferedReader.readLine()
         * method. We iterate until the BufferedReader return null which means
         * there's no more data to read. Each line will appended to a StringBuilder
         * and returned as String.
         */
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
    private static String connect(String jsonurl)
    {
        try {
            URL url = new URL(jsonurl);
            URLConnection urlConnection = url.openConnection();
            urlConnection.setConnectTimeout(10000);
            InputStream is = urlConnection.getInputStream();;
            String result= convertStreamToString(is);
            is.close();
            urlConnection.connect();
            return result;
        } catch (Exception ex) {
            Log.d("FetchingJsonFromServer",ex.toString());
        }
        return null;
    }

    public static String loadDevicesDataFromServer(String url)
    {
        ArrayList<Devices> devicesList = new ArrayList<Devices>();

        String response = connect(url);
       /* if(response == null)
            return null;
        try {
            JsonReader reader = new JsonReader(new StringReader(response));
            reader.beginObject();

            while (reader.hasNext()) {
                String fieldName = reader.nextName();

                if (fieldName.equals("devices") && reader.peek() != JsonToken.NULL) {
                    reader.beginArray();

                    while (reader.hasNext()) {
                        reader.beginObject();
                        Devices d = new Devices();

                        while (reader.hasNext()) {
                            String name = reader.nextName();

                            if (name.equals("deviceType") && reader.peek() != JsonToken.NULL) {
                                d.setDeviceType(reader.nextString());
                            }
                            else if (name.equals("model") && reader.peek() != JsonToken.NULL) {
                                d.setModel(reader.nextString());
                            }
                            else if (name.equals("name") && reader.peek() != JsonToken.NULL) {
                                d.setName(reader.nextString());
                            }
                            else
                                reader.skipValue();
                        }
                        reader.endObject();
                        devicesList.add(d);
                    }
                    reader.endArray();
                } else
                    reader.skipValue();
            }
            reader.endObject();
            reader.close();
        }  catch (Exception ex) {
            Log.d("ParsingJson",ex.toString());
        }
        */
        return response;
    }
}
